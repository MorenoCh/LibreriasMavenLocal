package tn5250j.interfaces;

public interface ScanListener
{
  public void scanned(String command, String remainder);
}